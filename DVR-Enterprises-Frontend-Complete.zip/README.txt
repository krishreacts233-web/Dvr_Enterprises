DVR Enterprises Frontend
Open index.html in a browser, or use VS Code + Live Server.
The site is frontend-only and uses the supplied business-card details.
The supplied card logo is cropped into assets/dvr-logo.jpg.
